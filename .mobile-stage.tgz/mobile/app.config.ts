// app.config.ts — Expo dynamic config
//
// Problem: @rnmapbox/maps Expo plugin only patches android/build.gradle when it's
// Groovy DSL. Expo SDK 56+ uses Kotlin DSL (.kts), so the plugin prints a warning
// and skips adding the Mapbox Maven repo. Gradle then falls back to JitPack which
// times out fetching com.mapbox.maps:android-ndk27.
//
// Fix: custom withDangerousMod that adds the Mapbox Maven repo to whichever
// .kts or .groovy build files exist after expo prebuild runs.

import { withDangerousMod } from "expo/config-plugins";
import * as fs from "fs";
import * as path from "path";

const MAPBOX_MAVEN = "https://api.mapbox.com/downloads/v2/releases/maven";

const withMapboxMavenRepo = (config: Record<string, unknown>): Record<string, unknown> =>
  withDangerousMod(config as any, [
    "android",
    async (c: any) => {
      const androidRoot: string = c.modRequest.platformProjectRoot;

      const candidates = [
        { file: path.join(androidRoot, "build.gradle.kts"), isKts: true },
        { file: path.join(androidRoot, "build.gradle"), isKts: false },
        { file: path.join(androidRoot, "settings.gradle.kts"), isKts: true },
        { file: path.join(androidRoot, "settings.gradle"), isKts: false },
      ];

      for (const { file, isKts } of candidates) {
        if (!fs.existsSync(file)) continue;

        const src = fs.readFileSync(file, "utf8");
        if (src.includes(MAPBOX_MAVEN)) {
          console.log(`[MapboxMaven] already in ${path.basename(file)}`);
          return c;
        }

        const entry = isKts
          ? `maven { url = uri("${MAPBOX_MAVEN}") }`
          : `maven { url "${MAPBOX_MAVEN}" }`;

        // Try injecting into an existing allprojects { repositories { ... } } block
        const allProjectsRepos = /(allprojects\s*\{[^{]*repositories\s*\{)/s;
        if (allProjectsRepos.test(src)) {
          const patched = src.replace(allProjectsRepos, `$1\n        ${entry}`);
          fs.writeFileSync(file, patched, "utf8");
          console.log(`[MapboxMaven] injected into allprojects.repositories in ${path.basename(file)}`);
          return c;
        }

        // Try dependencyResolutionManagement { repositories { ... } }
        const drm = /(dependencyResolutionManagement\s*\{[^{]*repositories\s*\{)/s;
        if (drm.test(src)) {
          const patched = src.replace(drm, `$1\n        ${entry}`);
          fs.writeFileSync(file, patched, "utf8");
          console.log(`[MapboxMaven] injected into dependencyResolutionManagement.repositories in ${path.basename(file)}`);
          return c;
        }
      }

      // Last resort: append a new allprojects block to build.gradle.kts
      const ktsPath = path.join(androidRoot, "build.gradle.kts");
      if (fs.existsSync(ktsPath)) {
        const existing = fs.readFileSync(ktsPath, "utf8");
        const appended = `${existing}\nallprojects {\n    repositories {\n        maven { url = uri("${MAPBOX_MAVEN}") }\n    }\n}\n`;
        fs.writeFileSync(ktsPath, appended, "utf8");
        console.log("[MapboxMaven] appended allprojects block to build.gradle.kts");
      }

      return c;
    },
  ]) as any;

const baseConfig = ({ config }: { config: Record<string, unknown> }): Record<string, unknown> => ({
  ...config,
  extra: {
    ...((config.extra as Record<string, unknown>) ?? {}),
    // EAS sets this on the builder. Without it every preview APK looks
    // identical from inside the app, which is how you end up testing a build
    // you already replaced.
    commit: (process.env.EAS_BUILD_GIT_COMMIT_HASH ?? "local").slice(0, 8),
  },
  plugins: [
    "expo-router",
    "expo-status-bar",
    "expo-web-browser",
    "expo-sqlite",
    "expo-secure-store",
    [
      "@rnmapbox/maps",
      {
        // The Mapbox SDK is fetched from a private Maven repo that needs a
        // secret download token. The plugin looks for RNMAPBOX_MAPS_DOWNLOAD_TOKEN,
        // but the EAS secret on this project is named MAPBOX_DOWNLOAD_TOKEN —
        // accept either rather than requiring the secret be recreated. Without
        // it Gradle falls back to JitPack and times out.
        RNMapboxMapsDownloadToken:
          process.env.RNMAPBOX_MAPS_DOWNLOAD_TOKEN ??
          process.env.MAPBOX_DOWNLOAD_TOKEN ??
          process.env.MAPBOX_DOWNLOADS_TOKEN,
      },
    ],
    [
      "expo-location",
      {
        locationWhenInUsePermission:
          "Waypoint uses your location to place you on your event's live map so organizers, your crew, and your emergency contacts can see where you are.",
        locationAlwaysAndWhenInUsePermission:
          "Waypoint shares your position with your event organizer and emergency contacts while you're riding, including when your phone is in your pocket or the screen is off. Tracking runs only while you have a session started, and you can stop it at any time.",
        isAndroidBackgroundLocationEnabled: true,
        isAndroidForegroundServiceEnabled: true,
      },
    ],
  ],
});

export default (args: { config: Record<string, unknown> }) =>
  withMapboxMavenRepo(baseConfig(args));
